/* dzip
 * by Ciaran Anscomb, 2011
 *
 * Disclaimer:
 * Possibly not fit for any purpose.  You're free to use, copy, modify and
 * redistribute so long as I don't get the blame for anything. */

#include <fcntl.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>

/* simple zip.  encodes as:
 * 1iiiiiii 0nnnnnnn - repeat 128-n (1-128) bytes from current + 1x (-ve 2s cmp)
 * 1iiiiiii 1jjjjjjj nnnnnnnn - repeat 128-n (1-256) bytes from current + 1ij
 * 0nnnnnnn - directly copy next 128-n (1-128) bytes */

/* mmap()ed file */
static uint8_t *map;

/* cursor position within the data map */
static off_t map_pos;

/* amount of bytes remaining */
static off_t bytes_remaining;

/* buffer for stdin */
static uint8_t *stdin_buffer;

/* Best match offset/length found */
static int match_offset, match_length;

/* Current run */
static off_t run_start;
int run_length;

static void dump_run(void);
static void dump_match(void);
static int count_match_length(off_t from, off_t to);
static void find_match(off_t to);

static void usage(const char *prog) {
	fprintf(stderr, "Usage: %s [-c] [-k] [-v] [infile]...\n", prog);
}

/*
static void missing_arg(const char *opt) {
	fprintf(stderr, "Missing argument to option %s\n", opt);
	exit(1);
}
*/

static int to_stdout = 0;
static int from_stdin = 0;
static int have_eof = 0;
static int keep = 0;
static int verbose = 0;

/* stats dumped in versbose mode */
static int count_run;
static int count_short_match;
static int count_long_match;

/* in/out stats */
static off_t in_bytes;
static off_t out_bytes;

int main(int argc, char **argv) {
	int argn;
	int in = -1;
	char *out_fname = NULL;

	/* parse options */
	argn = 1;
	while (argn < argc && argv[argn][0] == '-') {
		if (0 == strcmp(argv[argn], "-c")) {
			to_stdout = 1;
		} else if (0 == strcmp(argv[argn], "-k")) {
			keep = 1;
		} else if (0 == strcmp(argv[argn], "-v")) {
			verbose = 1;
		} else {
			usage(argv[0]);
			exit(1);
		}
		argn++;
	}

	char *in_fname = NULL;

	if (argn >= argc) {
		to_stdout = 1;
		from_stdin = 1;
		stdin_buffer = malloc(0x8100);
		if (!stdin_buffer) {
			perror("malloc failed");
			exit(1);
		}
		map = stdin_buffer;
		bytes_remaining = fread(stdin_buffer, 1, 0x8100, stdin);
		if (bytes_remaining < 0x8100) {
			if (!feof(stdin)) {
				perror("short read");
				exit(1);
			}
			have_eof = 1;
		}
	}

	for (;;) {

		if (argn < argc) {
			in_fname = argv[argn++];
			in = open(in_fname, O_RDONLY);
			if (in < 0) {
				perror(in_fname);
				exit(1);
			}
			struct stat statbuf;
			if (fstat(in, &statbuf) < 0) {
				perror(in_fname);
				exit(1);
			}
			if (!(statbuf.st_mode & S_IFREG)) {
				fprintf(stderr, "%s: not a regular file - ignoring\n", in_fname);
				exit(1);
			}
			bytes_remaining = statbuf.st_size;
			map = mmap(NULL, bytes_remaining, PROT_READ, MAP_PRIVATE, in, 0);
			if (map == MAP_FAILED) {
				perror("mmap failed");
				exit(1);
			}
		}

		if (!to_stdout) {
			out_fname = malloc(strlen(in_fname) + 4);
			if (!out_fname) {
				perror("malloc() failed");
				exit(1);
			}
			strcpy(out_fname, in_fname);
			strcat(out_fname, ".dz");
			if (freopen(out_fname, "wb", stdout) == NULL) {
				fprintf(stderr, "Failed to open '%s' for writing: ", out_fname);
				perror(NULL);
				exit(1);
			}
		}

		run_start = run_length = 0;
		match_offset = match_length = 0;
		map_pos = 0;
		/* reset stats */
		in_bytes = out_bytes = 0;
		count_run = count_short_match = count_long_match = 0;
		while (bytes_remaining > 0) {
			if (from_stdin && !have_eof && map_pos >= 0x8000) {
				memmove(stdin_buffer, stdin_buffer + 0x4000, 0x4100);
				size_t nread = fread(stdin_buffer + 0x4100, 1, 0x4000, stdin);
				if (nread < 0x4000) {
					if (!feof(stdin)) {
						perror("short read");
						exit(1);
					}
					have_eof = 1;
				}
				bytes_remaining += nread;
				map_pos -= 0x4000;
				if (run_start > 0)
					run_start -= 0x4000;
			}
			find_match(map_pos);
			/* short offset run > 2 bytes always worth doing */
			if (match_offset >= -128) {
				if (match_length > 2
				    /* or 2 bytes, and not already in a run */
				    || (match_length == 2 && run_length == 0)) {
					dump_match();
					continue;
				}
			}
			/* long offset run > 3 bytes always worth doing */
			if (match_length > 3
			    /* or 3 bytes, and not already in a run */
			    || (match_length == 3 && run_length == 0)) {
				dump_match();
				continue;
			}
			/* if already in a run, continue it */
			if (run_length > 0) {
				run_length++;
				map_pos++;
				in_bytes++;
				bytes_remaining--;
				/* maximum run length is 128 */
				if (run_length == 128) {
					dump_run();
				}
				continue;
			}
			/* otherwise, start a run */
			run_start = map_pos;
			run_length = 1;
			map_pos++;
			in_bytes++;
			bytes_remaining--;
		}
		dump_run();

		if (verbose) {
			if (out_fname) {
				fprintf(stderr, "%s:\t", out_fname);
			}
			fprintf(stderr, "%.1f%%", 100. * (1. - ((float)out_bytes / (float)in_bytes)));
		}

		if (verbose) {
			int total = count_run + count_short_match + count_long_match;
			fprintf(stderr, " -- run = %.1f%%, short = %.1f%%, long = %.1f%%\n", 100. * (float)count_run/total, 100. * (float)count_short_match/total, 100. * (float)count_long_match/total);
		}

		if (!to_stdout && !keep) {
			unlink(in_fname);
		}

		if (in > -1) {
			close(in);
		}

		if (argn >= argc || to_stdout)
			break;

	}

	return 0;
}

static void dump_run(void) {
	if (run_length == 0)
		return;
	int i;
	count_run++;
	fputc(128 - run_length, stdout);
	for (i = 0; i < run_length; i++) {
		fputc(map[run_start + i], stdout);
	}
	out_bytes += run_length + 1;
	run_length = run_start = 0;
}

static void dump_match(void) {
	dump_run();
	if (match_offset >= -128 && match_length <= 128) {
		count_short_match++;
		fputc(match_offset & 0xff, stdout);
		fputc(128 - match_length, stdout);
		out_bytes += 2;
	} else {
		count_long_match++;
		fputc(((match_offset >> 7) & 0x7f) | 0x80, stdout);
		fputc((match_offset & 0x7f) | 0x80, stdout);
		fputc((384 - match_length) & 0xff, stdout);
		out_bytes += 3;
	}
	map_pos += match_length;
	in_bytes += match_length;
	bytes_remaining -= match_length;
}

/* check possible length of match at 'from' */
static int count_match_length(off_t from, off_t to) {
	int length = 0;
	while (length < 256) {
		if (length >= bytes_remaining)
			return length;
		if (map[from] != map[to])
			return length;
		from++;
		to++;
		length++;
	}
	return length;
}

/* find best match */
static void find_match(off_t to) {
	match_length = 0;
	/* work backwards: even if an extra byte is used for offset (further
	 * back), a longer run exceeding the best so far will be at least as
	 * efficient */
	int f;
	for (f = 1; f <= 0x4000; f++) {
		if (f > to)
			return;
		int l = count_match_length(to - f, to);
		if (l > match_length) {
			match_length = l;
			match_offset = -f;
		}
	}
}
