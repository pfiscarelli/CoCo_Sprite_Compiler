/* dunzip
 * by Ciaran Anscomb, 2011
 *
 * Disclaimer:
 * Possibly not fit for any purpose.  You're free to use, copy, modify and
 * redistribute so long as I don't get the blame for anything. */

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>

/* simple zip.  encodes as:
 * 1iiiiiii 0nnnnnnn - repeat 128-n (1-128) bytes from current + 1i (-ve 2s cmp)
 * 1iiiiiii 1jjjjjjj nnnnnnnn - repeat 128-n (1-256) bytes from current + 1ij
 * 0nnnnnnn - directly copy next 128-n (1-128) bytes */

/* enough space for 16K of backreference data */
static uint8_t window[0x4000];

/* cursor position within the data window */
static int window_pos;

static void dump_backref(int offset, int count);

static void usage(const char *prog) {
	fprintf(stderr, "Usage: %s [-c] [-k] [infile]\n", prog);
}

/*
static void missing_arg(const char *opt) {
	fprintf(stderr, "Missing argument to option %s\n", opt);
	exit(1);
}
*/

static void short_read(void) {
	fprintf(stderr, "Short read\n");
	exit(1);
}

static int to_stdout = 0;
static int keep = 0;

int main(int argc, char **argv) {
	int argn;

	/* parse options */
	argn = 1;
	while (argn < argc && argv[argn][0] == '-') {
		if (0 == strcmp(argv[argn], "-c")) {
			to_stdout = 1;
		} else if (0 == strcmp(argv[argn], "-k")) {
			keep = 1;
		} else {
			usage(argv[0]);
			exit(1);
		}
		argn++;
	}

	char *in_fname = NULL;

	if (argn >= argc) {
		to_stdout = 1;
	}

	for (;;) {

		if (argn < argc) {
			in_fname = argv[argn++];
			if (freopen(in_fname, "rb", stdin) == NULL) {
				fprintf(stderr, "Failed to open %s for reading: ", in_fname);
				perror(NULL);
				exit(1);
			}
			int in_fileno = fileno(stdin);
			struct stat statbuf;
			if (fstat(in_fileno, &statbuf) < 0) {
				perror(NULL);
				exit(1);
			}
			if (!(statbuf.st_mode & S_IFREG)) {
				fprintf(stderr, "%s is not a regular file\n", in_fname);
				exit(1);
			}
		}

		if (!to_stdout) {
			char *dot = strrchr(in_fname, '.');
			if (!dot) {
				fprintf(stderr, "Unknown suffix\n");
				exit(1);
			}
			int base_length = dot - in_fname;
			if (base_length < 1) {
				fprintf(stderr, "Unknown suffix\n");
				exit(1);
			}
			char *out_fname = malloc(base_length + 1);
			if (!out_fname) {
				perror("malloc() failed");
				exit(1);
			}
			strncpy(out_fname, in_fname, base_length);
			out_fname[base_length] = 0;
			if (freopen(out_fname, "wb", stdout) == NULL) {
				fprintf(stderr, "Failed to open '%s' for writing: ", out_fname);
				perror(NULL);
				exit(1);
			}
		}

		int a;
		while ((a = fgetc(stdin)) != EOF) {
			if (a & 0x80) {
				int b;
				if ((b = fgetc(stdin)) == EOF) {
					short_read();
				}
				if (b & 0x80) {
					/* long backref */
					int offset = (a << 7) | (b & 0x7f);
					offset = -((offset ^ 0x7fff) + 1);
					int count;
					if ((count = fgetc(stdin)) == EOF) {
						short_read();
					}
					count = (384 - count) & 0xff;
					if (count == 0) count = 256;
					dump_backref(offset, count);
				} else {
					/* short backref */
					int offset = -((a ^ 0xff) + 1);
					int count = 128 - b;
					dump_backref(offset, count);
				}
			} else {
				int count;
				for (count = 128 - a; count > 0; count--) {
					int c;
					if ((c = fgetc(stdin)) == EOF) {
						short_read();
					}
					putchar(c);
					window[window_pos++] = c;
					window_pos %= sizeof(window);
				}
			}
		}

		if (!to_stdout && !keep) {
			unlink(in_fname);
		}

		if (argn >= argc || to_stdout)
			break;

	}

	return 0;
}

static void dump_backref(int offset, int count) {
	for (; count > 0; count--) {
		int from = window_pos + offset;
		while (from < 0) {
			from += sizeof(window);
		}
		putchar(window[from]);
		window[window_pos++] = window[from];
		window_pos %= sizeof(window);
	}
}
